package com.example.Quick.loan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickLoanApplication.class, args);
	}

}

package com.example.Debt.checker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DebtCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DebtCheckerApplication.class, args);
	}

}

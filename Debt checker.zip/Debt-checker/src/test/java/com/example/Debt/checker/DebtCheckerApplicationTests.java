package com.example.Debt.checker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebtCheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
